---
name: "Feature request \U0001F680"
about: Sugerir una idea
labels: enhancement

---

## Resumen
Breve explicación de la función.

### Ejemplo básico
Incluya un ejemplo básico o enlaces aquí.

### Motivación
¿Por qué hacemos esto? ¿Qué casos de uso admite? ¿Cuál es el resultado esperado?